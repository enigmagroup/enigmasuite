(function(){
    $('.btn-danger').click(function(){
        return confirm('Bist Du sicher?');
    });
})();
