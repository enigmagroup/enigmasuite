from app.models import *
from django.contrib import admin

admin.site.register(Address)
admin.site.register(Country)
admin.site.register(Option)
admin.site.register(Puppetmaster)
admin.site.register(Peering)
