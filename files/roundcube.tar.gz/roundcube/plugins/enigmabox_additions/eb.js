function rcube_check_email(a, b) {
    return true;
}
